"""
    FEATURES:
        1. buy_upgrades -> True 
            
           
        2. buy_decision_method -> метод покупки карточек (profitness
            
            
            
            
            )
        3. delay_between_attempts -> 30
    
    ACCOUNTS:
        name -> Название аккаунта. Так он будет виден в логе
        token -> 1718275255132ApK7MSjLH51YH7aQ5RvggQ9lwr5h4eILlw7U8h4eGhkhkNwqnba5FBGsJaPL5oRi940273614
        proxies -> настройки прокси, "кто знает - тот поймет". Если не нужен прокси, лучше убрать
        buy_upgrades -> Описано в FEATURES, можно указать для каждого аккаунта отдельно
        buy_decision_method -> Описано в FEATURES, можно указать для каждого аккаунта отдельно
"""

try:
    from config_local import FEATURES, ACCOUNTS
except:

    FEATURES = {
        "buy_upgrades": True,
        "buy_decision_method": "payback",
        "delay_between_attempts": 60 * 10,
    }


    ACCOUNTS = [
        {"name": "account1", "token": "", "proxies": {}},
        {"name": "account2", "token": "", "buy_upgrades": True, "buy_decision_method": "payback"},
    ]

for account in ACCOUNTS:
    account['buy_upgrades'] = account.get('buy_upgrades', FEATURES.get('buy_upgrades', True))
    account['buy_decision_method'] = account.get('buy_decision_method', FEATURES.get('buy_decision_method', 'payback'))